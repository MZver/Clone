addFirstTwo <- function(a) {
  result <- as.numeric(a[1]) + as.numeric(a[2])
  return(result)
}


