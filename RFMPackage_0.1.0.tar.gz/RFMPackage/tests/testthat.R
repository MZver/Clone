library(testthat)
library(RFMPackage)

test_check("RFMPackage")
