
test_that("sum up first two", {
  expect_equal(addFirstTwo(c(2,3)), 5)
  expect_equal(addFirstTwo(c(5,3)), 8)
})



